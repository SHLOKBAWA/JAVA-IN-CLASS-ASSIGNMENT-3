
    var t = document.getElementsByClassName("q");
    var change=0;
function launch()
{
     if(change < 11)
        {
            change++;
        }
    
    for(var i = 0; i < t.length; i++)
        {
            if(i==change)
                {
                    t[i].style.display = "block";
                }
            
            else
                {
                    t[i].style.display = "none";
                }
        }
    
    
}





